<?php if( '' != $gcse_content ) { ?>
	<?php echo $args['before_widget']; ?>
		<?php echo $gcse_content; ?>
	<?php echo $args['after_widget']; ?>
<?php } // end if ?>